public class Donnees {
    Imagette[] imagettes;

    public Donnees(Imagette[] tab) {
        imagettes = tab;
    }
}
