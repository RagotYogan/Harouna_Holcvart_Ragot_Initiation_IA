import java.io.*;

public class Imagette {
    int[][] tableau;

    int etiquette;

    public Imagette(int nbLigne, int nbColonne, int nbEtiquette) throws IOException {
        tableau = new int[nbLigne][nbColonne];
        etiquette = nbEtiquette;
    }


}

